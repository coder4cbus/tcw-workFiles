import { CcLogoDirective } from './cc-logo.directive';

describe('CcLogoDirective', () => {
  it('should create an instance', () => {
    const directive = new CcLogoDirective();
    expect(directive).toBeTruthy();
  });
});
